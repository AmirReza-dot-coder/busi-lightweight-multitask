Validation-only Grad-CAM: 6 fixed examples x 3 frozen seed-42 models.
CAM targets are the three final pre-softmax class scores, not segmentation pixels.
Native grids are retained in NPZ; upsampling is for display.
Each positive map is normalized independently; intensity is not comparable across maps.
A no-positive-CAM flag denotes an empty positive map, not proof of absent evidence.
Reference masks are displayed separately and never used to calculate the CAM.
These visualizations are qualitative diagnostics, not proof of clinical correctness.
Method: https://keras.io/examples/vision/grad_cam/ ; https://arxiv.org/abs/1610.02391
