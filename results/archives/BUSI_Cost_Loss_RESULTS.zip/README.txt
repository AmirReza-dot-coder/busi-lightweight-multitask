Loss ablation: plain CE (1:1:1) versus cost-sensitive weighted CE (1:1:2), both retrained under one paired protocol.
Class costs are normalized to mean 1 over TRAIN labels. They are cost ratios, not inverse-frequency class balancing.
Architecture, common warm-start network, task-loss mechanism, optimizer, data order, flips and checkpoint rule are held the same.
This measures the loss choice during the proposed training stage; the shared warm start already contains prior task learning.
All checkpoints include the initial network; selected epoch 0 means no checkpoint beat that initial state under the selection rule.
Both the missed-malignant and false-malignant counts must accompany Recall. Report null or negative results honestly.
All evaluation uses the existing 115 validation images. Prior test results have been inspected; this is not an independent test.
Weights and optimizer checkpoints stay in Drive; this ZIP includes only the result files.
Reference: https://keras.io/api/losses/probabilistic_losses/
