Augmentation correction: same full_lprm_v1 architecture, initial weights, loss and optimizer as controls.
Original controls: horizontal flip only. New training: declared paired geometric and image-only photometric augmentation.
Numerical augmentation ranges are experimental choices, not values claimed from the base paper.
Seeds 42,43,44 share a warm-start network; they vary continuation randomness.
All checkpoint selection uses validation only. Earlier test results were already seen; this follow-up is exploratory.
No images are removed or relabeled. No inference-time class gating or mask cleanup is applied.
All validation examples are reported; selected illustrations are chosen from original control errors only.
A retained initial model or a worse metric must be reported as such. Improved performance is not guaranteed.
The downloadable report excludes model and optimizer checkpoints, which stay in the Drive experiment folder.
Implementation references: https://keras.io/guides/custom_train_step_in_tensorflow/ ; https://pillow.readthedocs.io/en/stable/reference/Image.html
