BUSI single-task versus multi-task CORE study (validation only).
Nine fresh trainings: 3 modes x seeds 42,43,44, each 30 epochs, batch 8, Adam 1e-4.
Only the CNN is ImageNet-pretrained; no BUSI-trained weight warm start.
Shared CNN frozen; shared Transformer trainable; same head initialization for matched tasks.
LPRM, adaptive task weights and class costs disabled here to isolate core task sharing.
Classification-only trains without mask targets; segmentation-only trains without class targets.
Same epoch order/flips/initial weights, independently loaded models, fixed split and mask threshold.
MTL classification and segmentation checkpoints are selected separately by task-matched criteria.
Do not combine scores from two different selected checkpoints as a single model result.
all_selected_checkpoints.csv retains both real outputs for each MTL checkpoint.
Exact thresholded masks are packed in NPZ; per-image soft Dice/BCE are in CSV. Soft mask maps can be regenerated from saved models.
Classification labels are used for segmentation subgroup evaluation only, not segmentation training.
Parameters describe architecture size, not latency or deployment memory.
Previous test results have already been inspected; this follow-up provides exploratory validation evidence.
No test images are loaded. Similarity groups are not verified patient IDs.
ImageNet preprocessing: https://keras.io/api/applications/mobilenet/
Functional task graphs: https://keras.io/guides/functional_api/
